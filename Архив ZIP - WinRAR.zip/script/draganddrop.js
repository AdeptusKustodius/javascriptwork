// drug&drop
// dragstart
// drag
// dragenter
// dragleave
// dragover
// drop
// dragend


let parentElem = document.querySelectorAll('.black_shashka');

let childElem = parentElem.firstChild;
let childElem2 = parentElem.lastChild;
console.log(childElem,childElem2);